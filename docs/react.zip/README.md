
# 智能聊天系统

基于 React + TypeScript + Ant Design 构建的智能聊天应用。

## 技术栈

- **前端框架**: React 18 with TypeScript
- **UI 组件库**: Ant Design
- **构建工具**: Vite
- **样式**: Tailwind CSS
- **状态管理**: React Query
- **路由**: React Router DOM

## 功能特性

- 💬 实时聊天界面
- 📱 响应式设计
- 🎨 现代化的UI设计
- ⚡ 快速响应
- 🔄 消息历史记录

## 开发指南

```sh
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build

# 代码检查
npm run lint
```

## 项目结构

```
src/
  ├── components/     # 可复用组件
  ├── pages/         # 页面组件
  ├── hooks/         # 自定义hooks
  ├── lib/           # 工具函数
  └── styles/        # 样式文件
```

## 部署

项目可以通过 Vercel、Netlify 或任何支持静态部署的平台进行部署。
